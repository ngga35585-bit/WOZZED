package com.wozzed.browser

import android.app.Activity
import android.app.AlertDialog
import android.os.Build
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.content.Context
import android.content.SharedPreferences
import android.webkit.*
import android.widget.*
import android.text.InputType
import android.view.KeyEvent
import android.view.WindowManager

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var address: EditText
    private lateinit var webHolder: FrameLayout
    private lateinit var prefs: SharedPreferences
    private val tabs = mutableListOf<WebView>()
    private var active = 0
    private var loading = false
    private val bg = Color.rgb(8,8,8)
    private val panel = Color.rgb(23,23,23)
    private val white = Color.WHITE
    private val gray = Color.rgb(155,155,155)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        prefs = getSharedPreferences("wozzed", Context.MODE_PRIVATE)
        buildUi()
        newTab("https://www.google.com")
    }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(10))
        }
        val logo = TextView(this).apply {
            text = "W"; textSize = 25f; setTextColor(white); typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER; background = rounded(panel, 14); layoutParams = LinearLayout.LayoutParams(dp(42), dp(42))
        }
        val brand = TextView(this).apply {
            text = "WOZZED"; textSize = 17f; letterSpacing = .16f; setTextColor(white)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setPadding(dp(12), 0, 0, 0)
        }
        header.addView(logo); header.addView(brand)
        val spacer = View(this); header.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
        val tabBtn = smallButton("▢") { showTabs() }
        header.addView(tabBtn)
        root.addView(header)

        val addressRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(7), dp(14), dp(10))
        }
        address = EditText(this).apply {
            setSingleLine(true); textSize = 14f; setTextColor(white); setHintTextColor(gray)
            hint = "Search or enter address"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setPadding(dp(16), 0, dp(12), 0); background = rounded(panel, 18)
            setOnEditorActionListener { _, action, event ->
                if (action == EditorInfo.IME_ACTION_GO || event?.keyCode == KeyEvent.KEYCODE_ENTER) {
                    navigate(text.toString()); true
                } else false
            }
            layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f)
        }
        addressRow.addView(address)
        val go = smallButton("GO") { navigate(address.text.toString()) }
        addressRow.addView(go)
        root.addView(addressRow)

        webHolder = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root.addView(webHolder, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(12)); setBackgroundColor(bg)
        }
        bottom.addView(navButton("‹") { current()?.let { if (it.canGoBack()) it.goBack() } })
        bottom.addView(navButton("›") { current()?.let { if (it.canGoForward()) it.goForward() } })
        bottom.addView(navButton("↻") { current()?.reload() })
        bottom.addView(navButton("＋") { newTab("https://www.google.com") })
        bottom.addView(navButton("⋯") { showMenu() })
        root.addView(bottom)
        setContentView(root)
    }

    private fun newTab(url: String) {
        val wv = WebView(this)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.loadsImagesAutomatically = true
        wv.settings.allowFileAccess = false
        wv.settings.allowContentAccess = false
        wv.settings.javaScriptCanOpenWindowsAutomatically = false
        wv.settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) wv.settings.safeBrowsingEnabled = true
        CookieManager.getInstance().setAcceptCookie(true)
        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url.toString()
                return if (u.startsWith("http://") || u.startsWith("https://")) false else true
            }
            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                loading = true
                if (tabs.getOrNull(active) === view) address.setText(url)
            }
            override fun onPageFinished(view: WebView, url: String) {
                loading = false
                if (tabs.getOrNull(active) === view) address.setText(url)
                if (!url.startsWith("about:")) {
                    val h = prefs.getStringSet("history", emptySet())!!.toMutableSet()
                    h.add(url); prefs.edit().putStringSet("history", h).apply()
                }
            }
        }
        tabs.add(wv); activate(tabs.lastIndex); wv.loadUrl(url)
    }

    private fun activate(index: Int) {
        if (index !in tabs.indices) return
        active = index
        webHolder.removeAllViews()
        (tabs[index].parent as? android.view.ViewGroup)?.removeView(tabs[index])
        webHolder.addView(tabs[index], FrameLayout.LayoutParams(-1, -1))
        address.setText(tabs[index].url ?: "")
    }

    private fun current() = tabs.getOrNull(active)

    private fun navigate(raw: String) {
        val s = raw.trim()
        if (s.isEmpty()) return
        val url = when {
            s.startsWith("https://") || s.startsWith("http://") -> s
            s.contains(" ") || !s.contains(".") -> "https://www.google.com/search?q=" + java.net.URLEncoder.encode(s, "UTF-8")
            else -> "https://$s"
        }
        current()?.loadUrl(url)
        address.clearFocus()
    }

    private fun showTabs() {
        val names = tabs.mapIndexed { i, w -> "${i + 1}. ${w.title ?: w.url ?: "New tab"}" }.toMutableList()
        names.add("＋ New tab")
        AlertDialog.Builder(this).setTitle("WOZZED tabs").setItems(names.toTypedArray()) { _, which ->
            if (which == tabs.size) newTab("https://www.google.com") else activate(which)
        }.setNegativeButton("Close current") { _, _ ->
            if (tabs.size > 1) { tabs.removeAt(active).destroy(); activate((active - 1).coerceAtLeast(0)) }
        }.show()
    }

    private fun showMenu() {
        val options = arrayOf("Bookmarks", "Save current bookmark", "History", "Desktop site", "Clear browsing data", "About WOZZED")
        AlertDialog.Builder(this).setTitle("Menu").setItems(options) { _, which ->
            when (which) {
                0 -> showSaved("bookmarks", "Bookmarks")
                1 -> current()?.url?.let { addSaved("bookmarks", it); toast("Bookmark saved") }
                2 -> showSaved("history", "History")
                3 -> current()?.let { w ->
                    val desktop = !w.settings.userAgentString.contains("Windows NT")
                    w.settings.userAgentString = if (desktop) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36" else WebSettings.getDefaultUserAgent(this)
                    w.reload()
                }
                4 -> {
                    tabs.forEach { it.clearHistory(); it.clearCache(true) }
                    CookieManager.getInstance().removeAllCookies(null); CookieManager.getInstance().flush()
                    prefs.edit().remove("history").apply(); toast("Browsing data cleared")
                }
                5 -> AlertDialog.Builder(this).setTitle("WOZZED").setMessage("Created by becali.18m\nMinimal browser for Android.").setPositiveButton("OK", null).show()
            }
        }.show()
    }

    private fun addSaved(key: String, value: String) {
        val set = prefs.getStringSet(key, emptySet())!!.toMutableSet(); set.add(value)
        prefs.edit().putStringSet(key, set).apply()
    }
    private fun showSaved(key: String, title: String) {
        val values = prefs.getStringSet(key, emptySet())!!.toList().sorted()
        AlertDialog.Builder(this).setTitle(title).setItems(values.toTypedArray()) { _, i -> navigate(values[i]) }
            .setPositiveButton("OK", null).show()
    }

    private fun navButton(label: String, action: () -> Unit) = TextView(this).apply {
        text = label; textSize = 24f; setTextColor(white); gravity = Gravity.CENTER
        layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f); setOnClickListener { action() }
    }
    private fun smallButton(label: String, action: () -> Unit) = TextView(this).apply {
        text = label; textSize = 14f; setTextColor(white); gravity = Gravity.CENTER
        setPadding(dp(12), 0, dp(12), 0); layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        setOnClickListener { action() }
    }
    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onBackPressed() {
        val w = current()
        if (w != null && w.canGoBack()) w.goBack() else if (tabs.size > 1) {
            tabs.removeAt(active).destroy(); activate((active - 1).coerceAtLeast(0))
        } else super.onBackPressed()
    }
    override fun onDestroy() { tabs.forEach { it.destroy() }; super.onDestroy() }
}
