# WOZZED Browser

A minimal Android browser built with Kotlin and Android WebView. The interface uses a black, white, and gray palette.

## Features currently implemented

- Web browsing with Google search/address navigation
- Basic multi-tab creation, switching, and closing
- Back, forward, and reload controls
- Bookmarks and local browsing history
- Desktop user-agent toggle
- Clear browsing data (WebView history/cache, cookies, and saved history)
- Android Safe Browsing where supported

## Build an APK

### GitHub Actions (recommended)

1. Push this repository to GitHub on the `main` branch.
2. Open **Actions** and select **Build WOZZED APK**.
3. Run the workflow with **Run workflow**, or push a commit to `main`.
4. Open the completed run and download the `WOZZED-debug-apk` artifact.

The artifact contains `WOZZED-debug.apk`.

### Android Studio

Open the repository root in Android Studio, allow Gradle sync, then run the `app` configuration.

## Requirements

- Android Studio with Android SDK Platform 35 for local builds
- JDK 17
- Android 6.0 (API 23) or newer

## Current limitations

This is a starter browser, not a full Chrome replacement. A full extension runtime, userscript manager, download manager, upload/file chooser support, isolated private tabs, and production-grade ad blocking are not implemented.

## Developer

becali.18m
